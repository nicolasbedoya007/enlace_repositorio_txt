package com.example.organizador;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrganizadorApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrganizadorApplication.class, args);
	}

}
