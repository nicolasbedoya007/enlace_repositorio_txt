package com.example.organizador;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrganizadorApplicationTests {

	@Test
	void contextLoads() {
	}

}
