# - **Evidencia:** GA8-220501096-AA2-EV02 - APK (Desarrollar Módulos Móvil Según Requerimientos del Proyecto)

## Detalles de la Evidencia

- **Aprendiz:** Juan Nicolas Bedoya Bernal
- **Instructor:** FABIAN ROLANDO CABALLERO CORTES
- **Programa:** Tecnólogo en Análisis y Desarrollo de Software
- **Grupo:** Ficha 2521972
- **Institución de Formación:** Servicio Nacional de Aprendizaje (SENA)
- **Centro de Formación:** Centro de Materiales y ensayos
- **Año:** 2024

## Empezando

Para ejecutar la aplicación, simplemente corre

`yarn install && expo start`

Y escanea el código QR en la aplicación cliente de Expo.

## Vista del Aprendiz

<img src="./assets/portada.jpg" alt="Vista Portada" width="250"/>

### Repositorio

- [x] [Visita mi repositorio:https://github.com/nicolasbedoya007/enlace_repositorio_txt.
