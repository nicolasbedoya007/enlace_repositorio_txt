import React from "react";
import AppContainer from "./src/navigation/AppNavigation";

const App = () => <AppContainer />;

export default App;
