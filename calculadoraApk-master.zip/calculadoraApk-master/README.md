Aprendiz Jose Luis Moreno Ficha 2627043
Instructor Alejandro Zabala
Desarrollo actividad APK (Desarrollar módulos móvil según requerimientos del proyecto) GA8-220501096-AA2-EV02. Se programo en android studio una calculadora para operaciones basicas,
es decir suma, resta, multiplicacion y division. con posibilidad de borrar DEL, encender y apagar la calculadora ON, OFF
AC de reiniciar la operación 
